import React, { useEffect, useState } from 'react';
import axios from 'axios';

const Viewbook: React.FC = () => {
  const [state, setState] = useState<{ BookId: number, BookName: string }[]>([]);

  useEffect(() => {
    const fetchBooks = async () => {
      try {
        const token = localStorage.getItem('token');
        console.log('token:',token);
        if (!token) {
          throw new Error('No token found');
        }
        
        const response = await axios.get('http://localhost:9082/user/books', {
          headers: {
            Authorization: `Bearer ${token}`
          }
        });
        setState(response.data);
      } catch (error) {
        console.error('Error fetching books:', error);
      }
    };

    fetchBooks();
  }, []);

  return (
    <table>
      <thead>
        <tr key="header">
          {state.length > 0 && Object.keys(state[0]).map((key) => (
            <th key={key}>{key}</th>
          ))}
        </tr>
      </thead>
      <tbody>
        {state.map((item) => (
          <tr key={item.BookId}>
            {Object.values(item).map((val, idx) => (
              <td key={idx}>{val}</td>
            ))}
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export default Viewbook;
