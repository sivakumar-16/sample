import React from 'react'

function AdminDashboard() {
  return (
    <div>
        <h1>hi ..hello..vanakkam!</h1>
      
    </div>
  )
}

export default AdminDashboard
